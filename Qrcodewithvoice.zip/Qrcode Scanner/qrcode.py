import cv2
from pyzbar.pyzbar import decode
import pygame
import numpy as np
import time

def play_start_sound():
    start_sound = pygame.mixer.Sound("start.mp3")  # Load the start sound
    start_sound.play()

def play_end_sound():
    end_sound = pygame.mixer.Sound("pip.mp3")  # Load the end sound
    end_sound.play()

def play_scan_sound():
    scan_sound = pygame.mixer.Sound("output.mp3")  # Load the scan sound
    scan_sound.play()

def scan_qr_code():
    camera = cv2.VideoCapture(0)
    detected_codes = {}  # Dictionary to store detected QR codes and their last detection time

    # Play start sound
    play_start_sound()

    while True:
        _, frame = camera.read()

        # Decode QR code
        decoded_objects = decode(frame)
        current_time = time.time()
        
        for obj in decoded_objects:
            qr_data = obj.data.decode("utf-8")
            if qr_data not in detected_codes or current_time - detected_codes[qr_data] >= 5:  # Check if QR code is not detected in last 5 seconds
                # Draw bounding box around the QR code
                points = obj.polygon
                if len(points) > 4:
                    hull = cv2.convexHull(np.array([point for point in points], dtype=np.float32))
                    cv2.polylines(frame, [hull], True, (255, 0, 0), 3)

                # Decode data and display it
                print("QR Code data:", qr_data)
                cv2.putText(frame, qr_data, (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2, cv2.LINE_AA)
                
                # Play sound when new QR code is detected
                play_scan_sound()

                # Update the last detection time of the QR code
                detected_codes[qr_data] = current_time

        # Show the frame
        cv2.imshow("QR Code Scanner", frame)

        # Check for key press
        key = cv2.waitKey(1)
        if key == ord('q'):
            break

    # Play end sound
    play_end_sound()

    camera.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    print("Starting QR Code scanner...")
    pygame.mixer.init()  # Initialize the mixer
    scan_qr_code()
